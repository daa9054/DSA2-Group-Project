/*
Programmer: Alberto Bobadilla (labigm@gmail.com)
Date: 2014/05
*/
#ifndef __MAIN_H__
#define __MAIN_H__

#include "ApplicationClass.h"


#endif //__MAIN_H__
#include "Cannonball.h"

Cannonball::Cannonball(void)
{
	position = vector4(0.0f,0.0f,0.0f,0.0f);
	velocity = vector4(0.0f,0.0f,0.0f,0.0f);
	acceleration = vector4(0.0f,0.0f,0.0f,0.0f);
	gravity = vector4(0.0f,-1.0f,0.0f,0.0f);
	direction = vector4(0.0f,0.0f,0.0f,0.0f);
	netForce = vector4(0.0f,0.0f,0.0f,0.0f);
	isFired = false;
	initialShot = false;
}

Cannonball::~Cannonball(void)
{

}

// Getters
vector4 Cannonball::GetPos()
{
	return position;
}
vector4 Cannonball::GetVel()
{
	return velocity;
}
vector4 Cannonball::GetAccel()
{
	return acceleration;
}
vector4 Cannonball::GetDir()
{
	return direction;
}
bool Cannonball::GetIsFired()
{
	return isFired;
}

// Setters
void Cannonball::SetPos(vector4 pos)
{
	position = pos;
}
void Cannonball::SetVel(vector4 vel)
{
	velocity = vel;
}
void Cannonball::SetAccel(vector4 accel)
{
	acceleration = accel;
}
void Cannonball::SetDir(vector4 dir)
{
	direction = dir;
}

void Cannonball::SetIsFired(bool pFired)
{
	isFired = pFired;
}

void Cannonball::SetInitialShot(bool pInit)
{
	initialShot = pInit;
}

void Cannonball::AddForce(vector4 forceToAdd)
{
	netForce += forceToAdd;
}

void Cannonball::Update()
{
	if(isFired)
	{
		if(initialShot)
		{
			//Get force from manager
			initialShot = false;
		}

		AddForce(gravity);

		acceleration += netForce;

		velocity += acceleration;

		position += velocity;

		netForce.x = 0.0f;
		netForce.y = 0.0f;
		netForce.z = 0.0f;
	}

	if(position.y < 0.0f)
	{
		//position =
		//Get managers position
		isFired = false;
		position = vector4(0.0f, 0.0f, 0.0f, 1.0f);
	}
}

// Calculates the projectile motion physics for the cannonball
